#include <stdio.h>
#include <stdlib.h>

int main()
{
    int valor,i=0;

    printf("Ingrese un valor:");
    scanf("%d",&valor);
    printf("\nEjecutando el while\n");

    // CICLO WHILE - EJEMPLO ESTANDAR
    while (i<valor){
        printf("%d|",i);
        i++;
    }
    printf("\n");

    system("PAUSE");
    printf("\nAhora los mismo pero mas simplificado!\n");

    // CICLO WHILE - EJEMPLO SIN LLAVES
    i=0; // volvemos la variable i, que es nuestro contador, a cero
    while (i<valor)
        printf("%d|",i++); // de esta forma, el ++ se ejecuta despues de ejecutar el printf (es post incremento)
    printf("\n");

    system("PAUSE");

    // CICLO WHILE - EJEMPLO DE CODIGO INALCANZABLE
    i=5;
    while(i<4){
        printf("Codigo inalcanzable!\n");
        i++;
    }
    printf("Acabamos de saltear un ciclo while completo\n");
    system("PAUSE");


    // CICLO WHILE - EJEMPLO DE CICLO INFINITO
    i=5;
    while (i>4){
        printf("Ciclo infinito!!!");
        i++;
        // ups, le pifie a la condicion
        // estos son los PEORES errores, porque no se ven a simple vista en el codigo
    }

    return 0;
}
